package selectServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * サーブレット
 * HTMLから情報を受け取り、表示させる処理
 *
 * 問①・②の回答をお願いします。
 *
 */
public class SelectServlet extends HttpServlet {


	 String month;
	 String value;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        value = request.getParameter("month");
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

		// 問② エビデンスと同じ表示になるように修正しましょう。
        out.println("今は" + month + "です。");
    }
}
